%{
The variables loaded are: foldInds,holdFeats, holdGRF, and holdLabs. All
samples were previously randomized

"foldInds" contains the indices where each fold begins and ends for the 5
fold cross-validation. The description of the data within each fold is in
the project report.

"holdFeats" contains all the user defined features. The definitions of each
feature can be found at the bottom of this script. Each sample is a row
vector within holdFeats.

"holdGRF" contains the full vGRF timeseries for each gait cycle. Each
sample is a row vector within holdGRF

"holdLabs" is the column vector of the non-scuff (0) and scuff (1) labels
assigned to each sample.

%}

clear; close all; clc; fclose all;

load('data4_logRegr');



featsUse = [7 9 10]; % select the features to use
k = size(foldInds,1); % number of folds
holdFeats = holdFeats./mean(holdFeats); % normalize the features
grps = 1:k; % array containing the fold numbers

% initializations
B = cell(k,1);
foldAccuracy = zeros(1,k);
numTrue = zeros(k,2);
numTest = numTrue;
%% Loop through the different folds
for i = 1:k 
	% select the folds that will be used for training and testing
	tempGrp = grps;
	testGrps = tempGrp(i);
	tempGrp(i) = [];
	trainGrps = tempGrp;

	% get the sample indices for the training and testing, then 
	[trainInds,testInds] = assembleGroupInds(foldInds,trainGrps,testGrps);
	trainLabs = holdLabs(trainInds);
	trainFeats = holdFeats(trainInds,featsUse);
	testLabs = holdLabs(testInds);
	testFeats = holdFeats(testInds,featsUse);

	% train the algorithm
	B{i}= mnrfit(trainFeats,categorical(trainLabs));

	% classify the testing data
	result = mnrval(B{i},testFeats);
	[val,predRes] = max(result'); % take max posterior probabilties

	% create a matrix containing of the predicted and manually classifed
	% labels
	compArr = [predRes' testLabs+1];
	foldAccuracy(i) = mean(diff(compArr')==0);

	% asses the accuracy of the method
	for a = 1:2
		numTest(i,a) = length(find(compArr(:,2) == a)); % get the count of that test label
		numTrue(i,a) = length(find(compArr(:,1) == a & compArr(:,2) == a));
		tallKeq5{i}(a,:) = [numTrue(i,a)/numTest(i,a) (numTest(i,a)-numTrue(i,a))/numTest(i,a)];
	end
end

%% Figure out how well it did
totTrue = sum(numTrue);
totTest = sum(numTest);
totFalse = totTest-totTrue;

res5 = tallKeq5{1};
for i = 2:k
	res5 = res5+tallKeq5{i};
end
avgRes5 = res5/k;

%% Plot the results
% need to rearrange the matrices to plot how I wanted
avgRes5(2,:) = avgRes5(2,[2 1])';
totRes = flipud([totFalse(1) totTrue(2); totTrue(1) totFalse(2)]);

% plot the heatmap of the data
[xx,yy] = meshgrid(1:3,1:3);
rep5 = avgRes5;
avgRes5 = avgRes5';
rep5(end+1,:) = rep5(end,:);
rep5(:,end+1) = rep5(:,end);
figure; hold on; view(2);
s = surf(xx,yy,rep5','EdgeColor','none');
colormap turbo;
% cbar = colorbar;
set(gca,'XTick',[1 2]+0.5,'YTick',[1 2]+0.5,'XTickLabel',{'Non-Scuff','Scuff'},'YTickLabel',{'Non-Scuff','Scuff'},'FontSize',16)
xs = [1 2]+0.5;
ys = xs;
heatMapLabs = cell(2,2);
for i = 1:2
	for j = 1:2
		temp = sprintf('%d (%0.1f',totRes(j,i),avgRes5(j,i)*100);
		text(xs(i),ys(j),2,[temp '%)'],'HorizontalAlignment','center','Color','w','FontSize',14);
	end
end
xlabel('Manually Classified','FontSize',20)
ylabel('Prediction','FontSize',20)

%% Function to select the sample indices for the training and testing folds

function [trainInds,testInds] = assembleGroupInds(foldInds,trainGrps,testGrps)
	trainInds = [];
	for j = 1:length(trainGrps) % loop through the number of groups
		trainInds = [trainInds foldInds(trainGrps(j),1):foldInds(trainGrps(j),2)];
	end
	testInds = [];
	for j = 1:length(testGrps)
		testInds = [testInds foldInds(testGrps(j),1):foldInds(testGrps(j),2)];
	end
end

%% Description of GRF features
%{
F1: Gait cycle % when the vGRF was < 20N (toe-off location)
F2: Location of maximum vGRF between F1 and the end of the gait cycle
F3: vGRF value at F2
F4: Gait cycle % between 50-100 where dvGRF/dt is > 0
F5: vGRF at F4
F6: Gait cycle % after F3 where dvGRF/dt is < 0
F7: vGRF at F6
F8: Gait cycle % where dvGRF/dt is > 0 after F6
F9: vGRF at F8
F10: Gait cycle % where vGRF is first < 0N
F11: Gait cycle % of second vGRF peak
F12: Gait cycle % b/w F1 and F12
F13: Approximate value of the vGRF in the middle of the descending limb
F14: Approximate value of dvGRF/dt in the middle of the descending limb
F15: apGRF at F1
F16: Maximum apGRF from 50-95% of gait
F17: Gait cycle % where F16 occurs
F18: Maximum apGRF from F1 to 100% of the gait cycle
F19: Gait cycle % where F18
F20: Difference between F1 and F2
F21: Difference in time between F6 and F4
F22: Difference between F8 & F6
F23: Difference between F8 & F4
F24: Difference between F1 and F10
%}